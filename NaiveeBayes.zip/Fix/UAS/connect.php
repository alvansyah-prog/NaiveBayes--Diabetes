<?php

//mysqli_connect("Alamat Server","USername DB", "PW DB", "Nama DB")
$conn = mysqli_connect("localhost", "root", "", "KB");

// if ($conn) {
//   echo "Berhasil Connect";
// } else {
//   echo "Gagal Connect";
// }
?>
